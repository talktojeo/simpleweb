using Microsoft.EntityFrameworkCore;
using SimpleApp.Data;

var builder = WebApplication.CreateBuilder(args);

// Use connection string from Azure App Service settings
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();
var app = builder.Build();

app.MapControllers();
app.Run();
